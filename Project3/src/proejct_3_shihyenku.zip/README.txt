Homework Project III: Longest common subsequence 
Name: Shih-Yen Ku
TIGP ID: 9951809

File description:
1. alignment_obj.py: contains the class and functions
2. alignment_console.py: contains the console mode of alignment program
3. align_prj3_gui.py: contains the GUI mode of alignment program

Input Example: (two sequence)
TGCATA
ATCTGAT

Usage:
1. Console mode: python alignment_console.py
2. GUI mode: double click the motif_prj3_gui.py

Output:
Longest common subsequence
The first matrix is score
The second matrix is storing the directions. ul: upper left; left: left; up: up.